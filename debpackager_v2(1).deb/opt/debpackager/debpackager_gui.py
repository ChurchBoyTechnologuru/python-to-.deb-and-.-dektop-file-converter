
import customtkinter as ctk
from tkinter import filedialog, messagebox
import os
import shutil
from pathlib import Path

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

class DebPackager(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("📦 Python to .deb Packager")
        self.geometry("800x550")

        self.title_label = ctk.CTkLabel(self, text="🛠️ Python .deb Packager Tool", font=("Helvetica", 22, "bold"))
        self.title_label.pack(pady=20)

        self.select_btn = ctk.CTkButton(self, text="📂 Select Python File", command=self.choose_file, font=("Helvetica", 16))
        self.select_btn.pack(pady=5)

        self.file_label = ctk.CTkLabel(self, text="", text_color="gray", font=("Helvetica", 14))
        self.file_label.pack(pady=5)

        self.name_entry = ctk.CTkEntry(self, placeholder_text="Enter Package Name", font=("Helvetica", 16), width=400)
        self.name_entry.pack(pady=10)

        self.desc_entry = ctk.CTkEntry(self, placeholder_text="Enter Package Description", font=("Helvetica", 16), width=400)
        self.desc_entry.pack(pady=10)

        self.choose_dest_btn = ctk.CTkButton(self, text="📁 Choose Destination Folder", command=self.choose_dest, font=("Helvetica", 16))
        self.choose_dest_btn.pack(pady=10)

        self.dest_label = ctk.CTkLabel(self, text="", text_color="gray", font=("Helvetica", 14))
        self.dest_label.pack(pady=5)

        self.build_btn = ctk.CTkButton(self, text="🛠️ Build .deb Package", command=self.build_deb, font=("Helvetica", 18))
        self.build_btn.pack(pady=20)

    def choose_file(self):
        file = filedialog.askopenfilename(filetypes=[("Python files", "*.py")])
        if file:
            self.file_path = file
            self.file_label.configure(text=file)

    def choose_dest(self):
        folder = filedialog.askdirectory()
        if folder:
            self.dest_path = folder
            self.dest_label.configure(text=folder)

    def build_deb(self):
        if not hasattr(self, "file_path") or not self.file_path:
            messagebox.showwarning("Missing File", "No Python file selected.")
            return

        pkg_name = self.name_entry.get().strip() or "mypackage"
        description = self.desc_entry.get().strip() or "Packaged Python app"
        dest_dir = Path(self.dest_path) if hasattr(self, "dest_path") else Path.home()
        build_dir = Path("/tmp") / f"{pkg_name}_build"
        debian_dir = build_dir / "DEBIAN"
        bin_dir = build_dir / "usr/local/bin"
        opt_dir = build_dir / f"opt/{pkg_name}"
        desktop_dir = build_dir / "usr/share/applications"

        for d in [debian_dir, bin_dir, opt_dir, desktop_dir]:
            d.mkdir(parents=True, exist_ok=True)

        # Control file
        (debian_dir / "control").write_text(f"""Package: {pkg_name}
Version: 1.0
Section: utils
Priority: optional
Architecture: all
Depends: python3
Maintainer: Auto Packager <packager@example.com>
Description: {description}
""")

        # Launcher script
        launcher_path = bin_dir / pkg_name
        launcher_path.write_text(f"""#!/usr/bin/env python3
import os
os.system('python3 /opt/{pkg_name}/{Path(self.file_path).name}')
""")

        launcher_path.chmod(0o755)

        # Desktop entry
        (desktop_dir / f"{pkg_name}.desktop").write_text(f"""[Desktop Entry]
Name={pkg_name}
Comment={description}
Exec={pkg_name}
Icon=utilities-terminal
Terminal=false
Type=Application
Categories=Utility;
""")

        # Copy script to opt directory
        shutil.copy(self.file_path, opt_dir / Path(self.file_path).name)

        # Build .deb
        deb_path = Path(dest_dir) / f"{pkg_name}.deb"
        os.system(f"dpkg-deb --build {build_dir} '{deb_path}'")

        messagebox.showinfo("Done", f".deb created at:
{deb_path}")

if __name__ == "__main__":
    app = DebPackager()
    app.mainloop()
