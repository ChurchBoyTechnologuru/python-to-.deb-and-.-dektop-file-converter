
import customtkinter as ctk
from tkinter import filedialog, messagebox
import os
import shutil
from pathlib import Path

ctk.set_appearance_mode("System")
ctk.set_default_color_theme("blue")

class DebPackager(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("📦 Python to .deb Packager")
        self.geometry("700x500")

        self.label = ctk.CTkLabel(self, text="Select your Python file to package:", font=("Arial", 16))
        self.label.pack(pady=20)

        self.select_btn = ctk.CTkButton(self, text="📂 Choose File", command=self.choose_file)
        self.select_btn.pack()

        self.file_label = ctk.CTkLabel(self, text="", text_color="gray")
        self.file_label.pack(pady=10)

        self.name_entry = ctk.CTkEntry(self, placeholder_text="Package Name")
        self.name_entry.pack(pady=10)

        self.build_btn = ctk.CTkButton(self, text="⚙️ Create .deb Package", command=self.build_deb)
        self.build_btn.pack(pady=20)

    def choose_file(self):
        file = filedialog.askopenfilename(filetypes=[("Python files", "*.py")])
        if file:
            self.file_path = file
            self.file_label.configure(text=file)

    def build_deb(self):
        if not hasattr(self, "file_path") or not self.file_path:
            messagebox.showwarning("Missing", "No Python file selected.")
            return

        pkg_name = self.name_entry.get().strip() or "mypackage"
        build_dir = Path("/tmp") / f"{pkg_name}_build"
        debian_dir = build_dir / "DEBIAN"
        bin_dir = build_dir / "usr/local/bin"
        opt_dir = build_dir / f"opt/{pkg_name}"

        for d in [debian_dir, bin_dir, opt_dir]:
            d.mkdir(parents=True, exist_ok=True)

        (debian_dir / "control").write_text(f"""Package: {pkg_name}
Version: 1.0
Section: utils
Priority: optional
Architecture: all
Depends: python3
Maintainer: Auto Packager <packager@example.com>
Description: Packaged Python app from GUI.
""")
        # Launcher
        launcher_path = bin_dir / pkg_name
        launcher_path.write_text(f"""#!/usr/bin/env python3
import os
os.system('python3 /opt/{pkg_name}/{Path(self.file_path).name}')
""")
        launcher_path.chmod(0o755)

        shutil.copy(self.file_path, opt_dir / Path(self.file_path).name)

        deb_path = Path.home() / f"{pkg_name}.deb"
        os.system(f"dpkg-deb --build {build_dir} {deb_path}")

        messagebox.showinfo("Done", f".deb created at: {deb_path}")

if __name__ == "__main__":
    app = DebPackager()
    app.mainloop()
